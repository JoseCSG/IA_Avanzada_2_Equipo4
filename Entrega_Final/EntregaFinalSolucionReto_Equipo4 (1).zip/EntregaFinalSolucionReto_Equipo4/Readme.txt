Esta carpeta contiene el flujo que siguio el equipo 4 para la solucion del Reto y se debe seguir el siguiente orden de ejecucion para llegar a la misma solucion:
1-. Limpieza.ipnyb 							| Contiene la limpieza y transformacion de las tablas iniciales
2-. TablasFact.ipnyb 						| Contien la generacion de las tablas de hechos
3-. Clustering.ipnyb						| Contiene la generacion de los clusters tanto de Clientes como de productos
4-. PrediccionProductosEmbeddings.ipnyb		| Generacion de embeddings para predicciones de Clientes
5-. PrediccionesClientesPorMes.ipnyb		| Generacion Modelo prediccion de venta de clientes por mes
6-. PrediccionesProductos.ipnyb				| Agrupacion de proceso de Clusterizacion y Prediccion donde saca tabla con el top 50 de mejores clientes de cada producto con la venta promedio de cada mes